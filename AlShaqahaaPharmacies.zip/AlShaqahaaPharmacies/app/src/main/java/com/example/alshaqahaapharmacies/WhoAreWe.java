package com.example.alshaqahaapharmacies;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class WhoAreWe extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_who_are_we);
    }
}