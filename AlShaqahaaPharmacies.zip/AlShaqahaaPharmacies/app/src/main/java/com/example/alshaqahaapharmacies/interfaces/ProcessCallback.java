package com.example.alshaqahaapharmacies.interfaces;

public interface ProcessCallback {

    void onSuccess(String message);

    void onFailure(String message);
}
